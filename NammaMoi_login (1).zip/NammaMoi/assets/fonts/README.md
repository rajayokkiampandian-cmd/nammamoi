# assets/fonts

Fonts are loaded from Google Fonts via `<link>` tags in the HTML head (Noto Sans Tamil + Poppins), so no local font files are required.

If you need fully offline/self-hosted fonts (no external requests), download the .woff2 files for Noto Sans Tamil and Poppins and place them here, then add an @font-face block to css/style.css pointing at these local files.
