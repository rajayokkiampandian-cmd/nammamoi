# assets/images

Add your real screenshots/photos here, for example:
- `og-cover.jpg` (1200x630) — referenced in index.html's Open Graph / Twitter Card meta tags.
- App screenshots if you want to swap the CSS-drawn phone mockup in the hero for a real one.

No images are bundled by default — the entire hero/dashboard preview is built with inline SVG and CSS so the site works fully offline with zero binary assets.
